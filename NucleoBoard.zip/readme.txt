make flash-remote USER=chipfc PASSWD=chipfc@123 SERVER=0.tcp.ap.ngrok.io PORT=16061
https://chipfcserver-uzf.tunnels.onboardbase.com/